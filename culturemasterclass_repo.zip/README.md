# Master Class Culture Camp

This repository hosts the public landing page for the Master Class Culture Camp — part of Tailwind Radar.
Built with Tailwind CSS, HTML5, and minimal dependencies.
